# NEON DISTRICT: Last Mile

An original third-person 3D open-city browser game prototype. It is a courier/exploration sandbox and is not affiliated with or a copy of any existing franchise.

## Play on your Mac

The game uses a Three.js ES module loaded from jsDelivr, so it needs an internet connection. Start it through a local web server (rather than opening `index.html` directly as a `file://` URL):

1. Download and unzip `neon_district_3d_web_release.zip`.
2. Open **Terminal**.
3. Type `cd ` (with a space), drag the extracted folder into Terminal, and press Return.
4. Run `python3 -m http.server 8000`.
5. Open Safari or Chrome and visit `http://localhost:8000`.
6. Click **ENTER THE CITY**. Use a keyboard and mouse/trackpad.

To stop the local server later, return to Terminal and press `Control + C`.

## Controls

- `W A S D` or arrow keys: walk / drive
- Mouse: look around (click the game to capture the pointer; press `Esc` to release)
- `E`: enter or exit a nearby car
- `Shift`: sprint / boost
- `Space`: jump on foot / handbrake while driving
- `Esc`: pause

## Publish on the web

### itch.io

1. Create a new project on itch.io and choose **HTML Game**.
2. Upload `neon_district_3d_web_release.zip`.
3. Set the game to be played in the browser and choose fullscreen or a responsive embed.

The ZIP is structured with `index.html` at its top level, as required by itch.io's HTML5 game uploader.

### GitHub Pages

1. Create a GitHub repository.
2. Upload `index.html` to the repository root (you can also include this README).
3. In the repository, open **Settings → Pages** and publish from the `main` branch and `/ (root)`.
4. Wait for GitHub Pages to publish, then open the URL it provides.

This is a playable prototype foundation. Before a public launch, test on the exact browsers/devices you intend to support, add your own title art and sound, and consider performance on lower-powered computers.
